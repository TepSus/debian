#!/bin/bash
# Script online dropbear, webmin, squid3, openvpn, openssh
# Dev by kguza
echo -e "Log OpenVPN User & IP Login"
cat /etc/openvpn/log.log