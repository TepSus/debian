#!/bin/bash
#����ǡѺʤ�Ի���

clear
echo -e "Auto Install SSH OVPN" 
echo -e ""
echo -e "\033[1;33mFor Debian 7-8"
echo -e "\033[1;33mFor VPS&Cloud"
echo -e ""
echo -e "\033[1;31mSell By :Kguza"
echo -e ""
echo -e "\033[1;36mLine http://kguza.xyz/Line"
echo -e "\033[1;36mFacebook http://kguza.xyz/Facebook"
echo -e "\033[1;36mwebsite http://kguza.xyz/website"
echo -e "\033[1;36mwebsite18+ https://goo.gl/on7fMA"
echo -e ""
